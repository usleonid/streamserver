# Requirements

- python3

# Installation

`python3 -m pip install -r requirements.txt`

# Scripts

All scripts in this folder contain a help section, run `python3 script.py --help` to see it.
